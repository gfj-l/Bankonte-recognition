% Wrapper Feature Selection Toolbox 
 
% There are more than 40 wrapper FS methods are offered 
% You may open < List_Method.m file > to check all available methods

%---Usage-------------------------------------------------------------
% If you wish to use 'PSO' (see example 1) then you write
% FS = jfs('pso',feat,label,opts);

% If you want to use 'SMA' (see example 2) then you write
% FS = jfs('sma',feat,label,opts);

% * All methods have different calling name (refer List_Method.m sf_idxfile)


%---Input-------------------------------------------------------------
% feat   : Feature vector matrix (Instances x Features)
% label  : Label matrix (Instances x 1)
% opts   : Parameter settings 
% opts.N : Number of solutions / population size (* for all methods)
% opts.T : Maximum number of iterations (* for all methods)
% opts.k : Number of k in k-nearest neighbor 

% Some methods have their specific parameters (example: PSO, GA, DE) 
% if you do not set them then they will define as default settings
% * you may open the < m.file > to view or change the parameters
% * you may use 'opts' to set the parameters of method (see example 1)
% * you may also change the < jFitnessFunction.m file >


%---Output------------------------------------------------------------
% FS    : Feature selection model (It contains several results)
% FS.sf : Index of selected features
% FS.ff : Selected features
% FS.nf : Number of selected features
% FS.c  : Convergence curve
% Acc   : Accuracy of validation model

tic
%% Number 1: efls
clear, clc, close;
efls_acc=[];%��
efls_fitness=[];%��
efls_nf=[];%��
for j=1:25         %��
% Ratio of validation data
 ho = 0.075; 
% % Common param eter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% 
 load rmb_B.mat; 
% Divide data into training and validation sets
 HO = cvpartition(label,'HoldOut',ho); 
 opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('efls',feat,label,opts);                 %��
 % Define index of selected features
 sf_idx = FS.sf;
 efls_nf(j,1)=FS.nf;                                    %��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 efls_acc(j,1)=Acc;             %��
 % Plot convergence
 efls_fitness(j,:)=FS.c;       %��
end
efls_fitness(26,:)=mean(efls_fitness,1);     %��
efls_acc(26,1)=mean(efls_acc,1);             %��
efls_nf(26,1)=mean(efls_nf,1)                %��

efls_fitness(27,1)=var(efls_fitness(26,:),0,2); 
efls_acc(27,1)=var(efls_acc(1:26,1),0,1);             %����
efls_nf(27,1)=var(efls_nf(1:26,1),0,1);

efls_fitness(28,1)=std(efls_fitness(26,:),0,2); 
efls_acc(28,1)=std(efls_acc(1:26,1),0,1);             %��׼��
efls_nf(28,1)=std(efls_nf(1:26,1),0,1);

efls_fitness(29,1)=min(efls_fitness(26,:),[],2);
efls_acc(29,1)=max(efls_acc(1:26,1),[],1);          %
efls_nf(29,1)=max(efls_nf(1:26,1),[],1);
    
%% Number 2: (aefls) 
aefls_acc=[];
aefls_fitness=[];
aefls_nf=[];
for k=1:25
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('aefls',feat,label,opts);
 % Define index of selected features
 sf_idx = FS.sf;
 aefls_nf(k,1)=FS.nf;
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 aefls_acc(k,1)=Acc;
 % Plot convergence
 aefls_fitness(k,:)=FS.c;
 
end
aefls_fitness(26,:)=mean(aefls_fitness,1);
aefls_acc(26,1)=mean(aefls_acc,1);
aefls_nf(26,1)=mean(aefls_nf,1);

aefls_fitness(27,1)=var(aefls_fitness(26,:),0,2); 
aefls_acc(27,1)=var(aefls_acc(1:26,1),0,1);             %����
aefls_nf(27,1)=var(aefls_nf(1:26,1),0,1);

aefls_fitness(28,1)=std(aefls_fitness(26,:),0,2); 
aefls_acc(28,1)=std(aefls_acc(1:26,1),0,1);             %��׼��
aefls_nf(28,1)=std(aefls_nf(1:26,1),0,1);

aefls_fitness(29,1)=min(aefls_fitness(26,:),[],2);
aefls_acc(29,1)=max(aefls_acc(1:26,1),[],1);          %
aefls_nf(29,1)=max(aefls_nf(1:26,1),[],1);

%% Number 3: (pf2ls) %��
pf2ls_acc=[];%��
pf2ls_fitness=[];%��
pf2ls_nf=[]; %��
for l=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('pf2ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 pf2ls_nf(l,1)=FS.nf;%��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 pf2ls_acc(l,1)=Acc;%��
 % Plot convergence
 pf2ls_fitness(l,:)=FS.c;%��
 
end
pf2ls_fitness(26,:)=mean(pf2ls_fitness,1);%��
pf2ls_acc(26,1)=mean(pf2ls_acc,1);%��
pf2ls_nf(26,1)=mean(pf2ls_nf,1);%��

pf2ls_fitness(27,1)=var(pf2ls_fitness(26,:),0,2); 
pf2ls_acc(27,1)=var(pf2ls_acc(1:26,1),0,1);             %����
pf2ls_nf(27,1)=var(pf2ls_nf(1:26,1),0,1);

pf2ls_fitness(28,1)=std(pf2ls_fitness(26,:),0,2); 
pf2ls_acc(28,1)=std(pf2ls_acc(1:26,1),0,1);             %��׼��
pf2ls_nf(28,1)=std(pf2ls_nf(1:26,1),0,1);

pf2ls_fitness(29,1)=min(pf2ls_fitness(26,:),[],2);
pf2ls_acc(29,1)=max(pf2ls_acc(1:26,1),[],1);          %
pf2ls_nf(29,1)=max(pf2ls_nf(1:26,1),[],1);

%% Number 4: (pf3ls) %��
pf3ls_acc=[];%��
pf3ls_fitness=[];%��
pf3ls_nf=[]; %��
for d=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('pf3ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 pf3ls_nf(d,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 pf3ls_acc(d,1)=Acc;%��2
 % Plot convergence
 pf3ls_fitness(d,:)=FS.c;%��2
 
end
pf3ls_fitness(26,:)=mean(pf3ls_fitness,1);%��
pf3ls_acc(26,1)=mean(pf3ls_acc,1);%��
pf3ls_nf(26,1)=mean(pf3ls_nf,1);%��

pf3ls_fitness(27,1)=var(pf3ls_fitness(26,:),0,2); 
pf3ls_acc(27,1)=var(pf3ls_acc(1:26,1),0,1);             %����
pf3ls_nf(27,1)=var(pf3ls_nf(1:26,1),0,1);

pf3ls_fitness(28,1)=std(pf3ls_fitness(26,:),0,2); 
pf3ls_acc(28,1)=std(pf3ls_acc(1:26,1),0,1);             %��׼��
pf3ls_nf(28,1)=std(pf3ls_nf(1:26,1),0,1);

pf3ls_fitness(29,1)=min(pf3ls_fitness(26,:),[],2);
pf3ls_acc(29,1)=max(pf3ls_acc(1:26,1),[],1);          %
pf3ls_nf(29,1)=max(pf3ls_nf(1:26,1),[],1);

%% Number 5: (athls) %��
athls_acc=[];%��
athls_fitness=[];%��
athls_nf=[]; %��
for x=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('athls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 athls_nf(x,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 athls_acc(x,1)=Acc;%��2
 % Plot convergence
 athls_fitness(x,:)=FS.c;%��2
 
end
athls_fitness(26,:)=mean(athls_fitness,1);%��
athls_acc(26,1)=mean(athls_acc,1);%��
athls_nf(26,1)=mean(athls_nf,1);%��

athls_fitness(27,1)=var(athls_fitness(26,:),0,2); 
athls_acc(27,1)=var(athls_acc(1:26,1),0,1);             %����
athls_nf(27,1)=var(athls_nf(1:26,1),0,1);

athls_fitness(28,1)=std(athls_fitness(26,:),0,2); 
athls_acc(28,1)=std(athls_acc(1:26,1),0,1);             %��׼��
athls_nf(28,1)=std(athls_nf(1:26,1),0,1);

athls_fitness(29,1)=min(athls_fitness(26,:),[],2);
athls_acc(29,1)=max(athls_acc(1:26,1),[],1);          %
athls_nf(29,1)=max(athls_nf(1:26,1),[],1);
%% Number 6: (achls) %��
achls_acc=[];%��
achls_fitness=[];%��
achls_nf=[]; %��
for y=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('achls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 achls_nf(y,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 achls_acc(y,1)=Acc;%��2
 % Plot convergence
 achls_fitness(y,:)=FS.c;%��2
 
end
achls_fitness(26,:)=mean(achls_fitness,1);%��
achls_acc(26,1)=mean(achls_acc,1);%��
achls_nf(26,1)=mean(achls_nf,1);%��

achls_fitness(27,1)=var(achls_fitness(26,:),0,2); 
achls_acc(27,1)=var(achls_acc(1:26,1),0,1);             %����
achls_nf(27,1)=var(achls_nf(1:26,1),0,1);

achls_fitness(28,1)=std(achls_fitness(26,:),0,2); 
achls_acc(28,1)=std(achls_acc(1:26,1),0,1);             %��׼��
achls_nf(28,1)=std(achls_nf(1:26,1),0,1);

achls_fitness(29,1)=min(achls_fitness(26,:),[],2);
achls_acc(29,1)=max(achls_acc(1:26,1),[],1);          %
achls_nf(29,1)=max(achls_nf(1:26,1),[],1);

%% Number 7: (pf4ls) %��
pf4ls_acc=[];%��
pf4ls_fitness=[];%��
pf4ls_nf=[]; %��
for h=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('pf4ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 pf4ls_nf(h,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 pf4ls_acc(h,1)=Acc;%��2
 % Plot convergence
 pf4ls_fitness(h,:)=FS.c;%��2
 
end
pf4ls_fitness(26,:)=mean(pf4ls_fitness,1);%��
pf4ls_acc(26,1)=mean(pf4ls_acc,1);%��
pf4ls_nf(26,1)=mean(pf4ls_nf,1);%��

pf4ls_fitness(27,1)=var(pf4ls_fitness(26,:),0,2); 
pf4ls_acc(27,1)=var(pf4ls_acc(1:26,1),0,1);             %����
pf4ls_nf(27,1)=var(pf4ls_nf(1:26,1),0,1);

pf4ls_fitness(28,1)=std(pf4ls_fitness(26,:),0,2); 
pf4ls_acc(28,1)=std(pf4ls_acc(1:26,1),0,1);             %��׼��
pf4ls_nf(28,1)=std(pf4ls_nf(1:26,1),0,1);

pf4ls_fitness(29,1)=min(pf4ls_fitness(26,:),[],2);
pf4ls_acc(29,1)=max(pf4ls_acc(1:26,1),[],1);          %
pf4ls_nf(29,1)=max(pf4ls_nf(1:26,1),[],1);

%% Number 8: ef3ls
ef3ls_acc=[];
ef3ls_fitness=[];
ef3ls_nf=[];
for i=1:25
% Ratio of validation data
 ho = 0.075; 
% Common parameter settings 
opts.N  = 30;     % number of solutcions
opts.T  = 500;    % maximum number of iterations
% Load dataset
load rmb_B.mat;
% Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
% Perform feature selection 
FS     = jfs('ef3ls',feat,label,opts);
% Define index of selected features
sf_idx = FS.sf;
ef3ls_nf(i,1)=FS.nf;
% Accuracy  
Acc    = jknn(feat(:,sf_idx),label,opts); 
ef3ls_acc(i,1)=Acc;
quanzhong=jknn(feat(:,sf_idx),label,opts)/(FS.nf/264);
% Plot convergence
ef3ls_fitness(i,:)=FS.c;
end
ef3ls_fitness(26,:)=mean(ef3ls_fitness,1);
ef3ls_acc(26,1)=mean(ef3ls_acc,1);
ef3ls_nf(26,1)=mean(ef3ls_nf,1);

ef3ls_fitness(27,1)=var(ef3ls_fitness(26,:),0,2); 
ef3ls_acc(27,1)=var(ef3ls_acc(1:26,1),0,1);             %����
ef3ls_nf(27,1)=var(ef3ls_nf(1:26,1),0,1);

ef3ls_fitness(28,1)=std(ef3ls_fitness(26,:),0,2); 
ef3ls_acc(28,1)=std(ef3ls_acc(1:26,1),0,1);             %��׼��
ef3ls_nf(28,1)=std(ef3ls_nf(1:26,1),0,1);

ef3ls_fitness(29,1)=min(ef3ls_fitness(26,:),[],2);
ef3ls_acc(29,1)=max(ef3ls_acc(1:26,1),[],1);          %
ef3ls_nf(29,1)=max(ef3ls_nf(1:26,1),[],1);
%%��Ӧ�Ⱥ�������
figure(1);
plot(efls_fitness(26,:),'-gp','Color',[0.96 0.59 0.17],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.96 0.59 0.17],'MarkerSize',6,'LineWidth',1); hold on;
plot(aefls_fitness(26,:),'-b>','MarkerFaceColor','b','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(pf2ls_fitness(26,:),'-c<','MarkerFaceColor','c','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;                                    
plot(pf3ls_fitness(26,:),'-mh','MarkerFaceColor','m','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;  
plot(athls_fitness(26,:),'-yo','Color',[0.08 0.6 0.25],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.08 0.6 0.25],'MarkerSize',6,'LineWidth',1); hold on;
plot(achls_fitness(26,:),'-ks','MarkerFaceColor','k','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(pf4ls_fitness(26,:),'-d','Color',[0.64 0.08 0.18],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.64 0.08 0.18],'MarkerSize',6,'LineWidth',1); hold on;
plot(ef3ls_fitness(26,:),'-r*','MarkerFaceColor','r','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
box off;
%grid on;
xlabel('Number of Iterations','FontSize',10);
ylabel('Fitness Value','FontSize',10); 
legend('EFLS','AEFLS','PF2LS','PF3LS','ATHLS','ACHLS','PF4LS','EF3LS','FontSize',10);
title('Objective Space','FontSize',10);
%% ׼ȷ������
Aver_acc=[];
Aver_acc=[efls_acc(26,1),aefls_acc(26,1),pf2ls_acc(26,1),pf3ls_acc(26,1),athls_acc(26,1),achls_acc(26,1),pf4ls_acc(26,1),ef3ls_acc(26,1)]
figure(2);
hold on;
bar(Aver_acc,'FaceColor',[0.64 0.08 0.18],'EdgeColor',[0.64 0.08 0.18],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'EFLS','AEFLS','PF2LS','PF3LS','ATHLS','ACHLS','PF4LS','EF3LS','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Accuracy','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Recognition Accuracy','FontSize',10);
%%ʣ����������
Aver_nf=[];
Aver_nf=[efls_nf(26,1),aefls_nf(26,1),pf2ls_nf(26,1),pf3ls_nf(26,1),athls_nf(26,1),achls_nf(26,1),pf4ls_nf(26,1),ef3ls_nf(26,1)]
figure(3);
hold on;
bar(Aver_nf,'FaceColor',[0.96 0.59 0.17],'EdgeColor',[0.96 0.59 0.17],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'EFLS','AEFLS','PF2LS','PF3LS','ATHLS','ACHLS','PF4LS','EF3LS','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Remaining Features','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Remaining Features','FontSize',10);
toc 







