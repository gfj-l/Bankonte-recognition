% Wrapper Feature Selection Toolbox 
 
% There are more than 40 wrapper FS methods are offered 
% You may open < List_Method.m file > to check all available methods

%---Usage-------------------------------------------------------------
% If you wish to use 'PSO' (see example 1) then you write
% FS = jfs('pso',feat,label,opts);

% If you want to use 'SMA' (see example 2) then you write
% FS = jfs('sma',feat,label,opts);

% * All methods have different calling name (refer List_Method.m sf_idxfile)


%---Input-------------------------------------------------------------
% feat   : Feature vector matrix (Instances x Features)
% label  : Label matrix (Instances x 1)
% opts   : Parameter settings 
% opts.N : Number of solutions / population size (* for all methods)
% opts.T : Maximum number of iterations (* for all methods)
% opts.k : Number of k in k-nearest neighbor 

% Some methods have their specific parameters (example: PSO, GA, DE) 
% if you do not set them then they will define as default settings
% * you may open the < m.file > to view or change the parameters
% * you may use 'opts' to set the parameters of method (see example 1)
% * you may also change the < jFitnessFunction.m file >


%---Output------------------------------------------------------------
% FS    : Feature selection model (It contains several results)
% FS.sf : Index of selected features
% FS.ff : Selected features
% FS.nf : Number of selected features
% FS.c  : Convergence curve
% Acc   : Accuracy of validation model


%% Number 1: cirls
clear, clc, close;
cirls_acc=[];%��
cirls_fitness=[];%��
cirls_nf=[];%��
for j=1:25         %��
% Ratio of validation data
 ho = 0.075; 
% % Common param eter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% 
 load rmb_B.mat; 
% Divide data into training and validation sets
 HO = cvpartition(label,'HoldOut',ho); 
 opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('cirls',feat,label,opts);                 %��
 % Define index of selected features
 sf_idx = FS.sf;
 cirls_nf(j,1)=FS.nf;                                    %��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 cirls_acc(j,1)=Acc;             %��
 % Plot convergence
 cirls_fitness(j,:)=FS.c;       %��
end
cirls_fitness(26,:)=mean(cirls_fitness,1);     %��
cirls_acc(26,1)=mean(cirls_acc,1);             %��
cirls_nf(26,1)=mean(cirls_nf,1)                %��

cirls_fitness(27,1)=var(cirls_fitness(26,:),0,2); 
cirls_acc(27,1)=var(cirls_acc(1:26,1),0,1);             %����
cirls_nf(27,1)=var(cirls_nf(1:26,1),0,1);

cirls_fitness(28,1)=std(cirls_fitness(26,:),0,2); 
cirls_acc(28,1)=std(cirls_acc(1:26,1),0,1);             %��׼��
cirls_nf(28,1)=std(cirls_nf(1:26,1),0,1);

cirls_fitness(29,1)=min(cirls_fitness(26,:),[],2);
cirls_acc(29,1)=max(cirls_acc(1:26,1),[],1);          %
cirls_nf(29,1)=max(cirls_nf(1:26,1),[],1);
    
%% Number 2: (el1ls) 
el1ls_acc=[];
el1ls_fitness=[];
el1ls_nf=[];
for k=1:25
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('el1ls',feat,label,opts);
 % Define index of selected features
 sf_idx = FS.sf;
 el1ls_nf(k,1)=FS.nf;
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 el1ls_acc(k,1)=Acc;
 % Plot convergence
 el1ls_fitness(k,:)=FS.c;
 
end
el1ls_fitness(26,:)=mean(el1ls_fitness,1);
el1ls_acc(26,1)=mean(el1ls_acc,1);
el1ls_nf(26,1)=mean(el1ls_nf,1);

el1ls_fitness(27,1)=var(el1ls_fitness(26,:),0,2); 
el1ls_acc(27,1)=var(el1ls_acc(1:26,1),0,1);             %����
el1ls_nf(27,1)=var(el1ls_nf(1:26,1),0,1);

el1ls_fitness(28,1)=std(el1ls_fitness(26,:),0,2); 
el1ls_acc(28,1)=std(el1ls_acc(1:26,1),0,1);             %��׼��
el1ls_nf(28,1)=std(el1ls_nf(1:26,1),0,1);

el1ls_fitness(29,1)=min(el1ls_fitness(26,:),[],2);
el1ls_acc(29,1)=max(el1ls_acc(1:26,1),[],1);          %
el1ls_nf(29,1)=max(el1ls_nf(1:26,1),[],1);

%% Number 3: (el2ls) %��
el2ls_acc=[];%��
el2ls_fitness=[];%��
el2ls_nf=[]; %��
for l=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('el2ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 el2ls_nf(l,1)=FS.nf;%��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 el2ls_acc(l,1)=Acc;%��
 % Plot convergence
 el2ls_fitness(l,:)=FS.c;%��
 
end
el2ls_fitness(26,:)=mean(el2ls_fitness,1);%��
el2ls_acc(26,1)=mean(el2ls_acc,1);%��
el2ls_nf(26,1)=mean(el2ls_nf,1);%��

el2ls_fitness(27,1)=var(el2ls_fitness(26,:),0,2); 
el2ls_acc(27,1)=var(el2ls_acc(1:26,1),0,1);             %����
el2ls_nf(27,1)=var(el2ls_nf(1:26,1),0,1);

el2ls_fitness(28,1)=std(el2ls_fitness(26,:),0,2); 
el2ls_acc(28,1)=std(el2ls_acc(1:26,1),0,1);             %��׼��
el2ls_nf(28,1)=std(el2ls_nf(1:26,1),0,1);

el2ls_fitness(29,1)=min(el2ls_fitness(26,:),[],2);
el2ls_acc(29,1)=max(el2ls_acc(1:26,1),[],1);          %
el2ls_nf(29,1)=max(el2ls_nf(1:26,1),[],1);

%% Number 4: (el3ls) %��
el3ls_acc=[];%��
el3ls_fitness=[];%��
el3ls_nf=[]; %��
for d=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('el3ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 el3ls_nf(d,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 el3ls_acc(d,1)=Acc;%��2
 % Plot convergence
 el3ls_fitness(d,:)=FS.c;%��2
 
end
el3ls_fitness(26,:)=mean(el3ls_fitness,1);%��
el3ls_acc(26,1)=mean(el3ls_acc,1);%��
el3ls_nf(26,1)=mean(el3ls_nf,1);%��

el3ls_fitness(27,1)=var(el3ls_fitness(26,:),0,2); 
el3ls_acc(27,1)=var(el3ls_acc(1:26,1),0,1);             %����
el3ls_nf(27,1)=var(el3ls_nf(1:26,1),0,1);

el3ls_fitness(28,1)=std(el3ls_fitness(26,:),0,2); 
el3ls_acc(28,1)=std(el3ls_acc(1:26,1),0,1);             %��׼��
el3ls_nf(28,1)=std(el3ls_nf(1:26,1),0,1);

el3ls_fitness(29,1)=min(el3ls_fitness(26,:),[],2);
el3ls_acc(29,1)=max(el3ls_acc(1:26,1),[],1);          %
el3ls_nf(29,1)=max(el3ls_nf(1:26,1),[],1);

%% Number 5: (el4ls) %��
el4ls_acc=[];%��
el4ls_fitness=[];%��
el4ls_nf=[]; %��
for x=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('el4ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 el4ls_nf(x,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 el4ls_acc(x,1)=Acc;%��2
 % Plot convergence
 el4ls_fitness(x,:)=FS.c;%��2
 
end
el4ls_fitness(26,:)=mean(el4ls_fitness,1);%��
el4ls_acc(26,1)=mean(el4ls_acc,1);%��
el4ls_nf(26,1)=mean(el4ls_nf,1);%��

el4ls_fitness(27,1)=var(el4ls_fitness(26,:),0,2); 
el4ls_acc(27,1)=var(el4ls_acc(1:26,1),0,1);             %����
el4ls_nf(27,1)=var(el4ls_nf(1:26,1),0,1);

el4ls_fitness(28,1)=std(el4ls_fitness(26,:),0,2); 
el4ls_acc(28,1)=std(el4ls_acc(1:26,1),0,1);             %��׼��
el4ls_nf(28,1)=std(el4ls_nf(1:26,1),0,1);

el4ls_fitness(29,1)=min(el4ls_fitness(26,:),[],2);
el4ls_acc(29,1)=max(el4ls_acc(1:26,1),[],1);          %
el4ls_nf(29,1)=max(el4ls_nf(1:26,1),[],1);
%% Number 6: (llsma) %��
llsma_acc=[];%��
llsma_fitness=[];%��
llsma_nf=[]; %��
for y=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('llsma',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 llsma_nf(y,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 llsma_acc(y,1)=Acc;%��2
 % Plot convergence
 llsma_fitness(y,:)=FS.c;%��2
 
end
llsma_fitness(26,:)=mean(llsma_fitness,1);%��
llsma_acc(26,1)=mean(llsma_acc,1);%��
llsma_nf(26,1)=mean(llsma_nf,1);%��

llsma_fitness(27,1)=var(llsma_fitness(26,:),0,2); 
llsma_acc(27,1)=var(llsma_acc(1:26,1),0,1);             %����
llsma_nf(27,1)=var(llsma_nf(1:26,1),0,1);

llsma_fitness(28,1)=std(llsma_fitness(26,:),0,2); 
llsma_acc(28,1)=std(llsma_acc(1:26,1),0,1);             %��׼��
llsma_nf(28,1)=std(llsma_nf(1:26,1),0,1);

llsma_fitness(29,1)=min(llsma_fitness(26,:),[],2);
llsma_acc(29,1)=max(llsma_acc(1:26,1),[],1);          %
llsma_nf(29,1)=max(llsma_nf(1:26,1),[],1);

%% Number 7: (lsma) %��
lsma_acc=[];%��
lsma_fitness=[];%��
lsma_nf=[]; %��
for h=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('lsma',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 lsma_nf(h,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 lsma_acc(h,1)=Acc;%��2
 % Plot convergence
 lsma_fitness(h,:)=FS.c;%��2
 
end
lsma_fitness(26,:)=mean(lsma_fitness,1);%��
lsma_acc(26,1)=mean(lsma_acc,1);%��
lsma_nf(26,1)=mean(lsma_nf,1);%��

lsma_fitness(27,1)=var(lsma_fitness(26,:),0,2); 
lsma_acc(27,1)=var(lsma_acc(1:26,1),0,1);             %����
lsma_nf(27,1)=var(lsma_nf(1:26,1),0,1);

lsma_fitness(28,1)=std(lsma_fitness(26,:),0,2); 
lsma_acc(28,1)=std(lsma_acc(1:26,1),0,1);             %��׼��
lsma_nf(28,1)=std(lsma_nf(1:26,1),0,1);

lsma_fitness(29,1)=min(lsma_fitness(26,:),[],2);
lsma_acc(29,1)=max(lsma_acc(1:26,1),[],1);          %
lsma_nf(29,1)=max(lsma_nf(1:26,1),[],1);

%% Number 8: logls
logls_acc=[];
logls_fitness=[];
logls_nf=[];
for i=1:25
% Ratio of validation data
 ho = 0.075; 
% Common parameter settings 
opts.N  = 30;     % number of solutcions
opts.T  = 500;    % maximum number of iterations
% Load dataset
load rmb_B.mat;
% Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
% Perform feature selection 
FS     = jfs('logls',feat,label,opts);
% Define index of selected features
sf_idx = FS.sf;
logls_nf(i,1)=FS.nf;
% Accuracy  
Acc    = jknn(feat(:,sf_idx),label,opts); 
logls_acc(i,1)=Acc;
quanzhong=jknn(feat(:,sf_idx),label,opts)/(FS.nf/264);
% Plot convergence
logls_fitness(i,:)=FS.c;
end
logls_fitness(26,:)=mean(logls_fitness,1);
logls_acc(26,1)=mean(logls_acc,1);
logls_nf(26,1)=mean(logls_nf,1);

logls_fitness(27,1)=var(logls_fitness(26,:),0,2); 
logls_acc(27,1)=var(logls_acc(1:26,1),0,1);             %����
logls_nf(27,1)=var(logls_nf(1:26,1),0,1);

logls_fitness(28,1)=std(logls_fitness(26,:),0,2); 
logls_acc(28,1)=std(logls_acc(1:26,1),0,1);             %��׼��
logls_nf(28,1)=std(logls_nf(1:26,1),0,1);

logls_fitness(29,1)=min(logls_fitness(26,:),[],2);
logls_acc(29,1)=max(logls_acc(1:26,1),[],1);          %
logls_nf(29,1)=max(logls_nf(1:26,1),[],1);
%%��Ӧ�Ⱥ�������
figure(1);
plot(cirls_fitness(26,:),'-gp','Color',[0.96 0.59 0.17],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.96 0.59 0.17],'MarkerSize',6,'LineWidth',1); hold on;
plot(el1ls_fitness(26,:),'-b>','MarkerFaceColor','b','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(el2ls_fitness(26,:),'-c<','MarkerFaceColor','c','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;                                    
plot(el3ls_fitness(26,:),'-mh','MarkerFaceColor','m','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;  
plot(el4ls_fitness(26,:),'-yo','Color',[0.08 0.6 0.25],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.08 0.6 0.25],'MarkerSize',6,'LineWidth',1); hold on;
plot(llsma_fitness(26,:),'-ks','MarkerFaceColor','k','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(lsma_fitness(26,:),'-d','Color',[0.64 0.08 0.18],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.64 0.08 0.18],'MarkerSize',6,'LineWidth',1); hold on;
plot(logls_fitness(26,:),'-r*','MarkerFaceColor','r','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
box off;
%grid on;
xlabel('Number of Iterations','FontSize',10);
ylabel('Fitness Value','FontSize',10); 
legend('CIRLS','EL1LS','EL2LS','EL3LS','EL4LS','LLSMA','LSMA','LOGLS','FontSize',10);
title('Objective Space','FontSize',10);
%% ׼ȷ������
Aver_acc=[];
Aver_acc=[cirls_acc(26,1),el1ls_acc(26,1),el2ls_acc(26,1),el3ls_acc(26,1),el4ls_acc(26,1),llsma_acc(26,1),lsma_acc(26,1),logls_acc(26,1)]
figure(2);
hold on;
bar(Aver_acc,'FaceColor',[0.64 0.08 0.18],'EdgeColor',[0.64 0.08 0.18],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'CIRLS','EL1LS','EL2LS','EL3LS','EL4LS','LLSMA','LSMA','LOGLS','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Accuracy','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Recognition Accuracy','FontSize',10);
%%ʣ����������
Aver_nf=[];
Aver_nf=[cirls_nf(26,1),el1ls_nf(26,1),el2ls_nf(26,1),el3ls_nf(26,1),el4ls_nf(26,1),llsma_nf(26,1),lsma_nf(26,1),logls_nf(26,1)]
figure(3);
hold on;
bar(Aver_nf,'FaceColor',[0.96 0.59 0.17],'EdgeColor',[0.96 0.59 0.17],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'CIRLS','EL1LS','EL2LS','EL3LS','EL4LS','LLSMA','LSMA','LOGLS','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Remaining Features','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Remaining Features','FontSize',10);