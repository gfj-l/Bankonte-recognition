% Wrapper Feature Selection Toolbox 
 
% There are more than 40 wrapper FS methods are offered 
% You may open < List_Method.m file > to check all available methods

%---Usage-------------------------------------------------------------
% If you wish to use 'PSO' (see example 1) then you write
% FS = jfs('pso',feat,label,opts);

% If you want to use 'SMA' (see example 2) then you write
% FS = jfs('sma',feat,label,opts);

% * All methods have different calling name (refer List_Method.m sf_idxfile)


%---Input-------------------------------------------------------------
% feat   : Feature vector matrix (Instances x Features)
% label  : Label matrix (Instances x 1)
% opts   : Parameter settings 
% opts.N : Number of solutions / population size (* for all methods)
% opts.T : Maximum number of iterations (* for all methods)
% opts.k : Number of k in k-nearest neighbor 

% Some methods have their specific parameters (example: PSO, GA, DE) 
% if you do not set them then they will define as default settings
% * you may open the < m.file > to view or change the parameters
% * you may use 'opts' to set the parameters of method (see example 1)
% * you may also change the < jFitnessFunction.m file >


%---Output------------------------------------------------------------
% FS    : Feature selection model (It contains several results)
% FS.sf : Index of selected features
% FS.ff : Selected features
% FS.nf : Number of selected features
% FS.c  : Convergence curve
% Acc   : Accuracy of validation model

tic
%% Number 1: SMA
clear, clc, close;
sma_acc=[];%��
sma_fitness=[];%��
sma_nf=[];%��
for j=1:25         %��
% Ratio of validation data
 ho = 0.075; 
% % Common param eter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% 
 load rmb_61.mat; 
% Divide data into training and validation sets
 HO = cvpartition(label,'HoldOut',ho); 
 opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('sma',feat,label,opts);                 %��
 % Define index of selected features
 sf_idx = FS.sf;
 sma_nf(j,1)=FS.nf;                                    %��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 sma_acc(j,1)=Acc;             %��
 % Plot convergence
 sma_fitness(j,:)=FS.c;       %��
end
sma_fitness(26,:)=mean(sma_fitness,1);     %��
sma_acc(26,1)=mean(sma_acc,1);             %��
sma_nf(26,1)=mean(sma_nf,1)                %��

sma_fitness(27,1)=var(sma_fitness(26,:),0,2); 
sma_acc(27,1)=var(sma_acc(1:26,1),0,1);             %����
sma_nf(27,1)=var(sma_nf(1:26,1),0,1);

sma_fitness(28,1)=std(sma_fitness(26,:),0,2); 
sma_acc(28,1)=std(sma_acc(1:26,1),0,1);             %��׼��
sma_nf(28,1)=std(sma_nf(1:26,1),0,1);

sma_fitness(29,1)=min(sma_fitness(26,:),[],2);
sma_acc(29,1)=max(sma_acc(1:26,1),[],1);          %
sma_nf(29,1)=max(sma_nf(1:26,1),[],1);
    
%% Number 2: (BK1LS) 
bk1ls_acc=[];
bk1ls_fitness=[];
bk1ls_nf=[];
for k=1:25
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% % Load dataset
 load rmb_61.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bk1ls',feat,label,opts);
 % Define index of selected features
 sf_idx = FS.sf;
 bk1ls_nf(k,1)=FS.nf;
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bk1ls_acc(k,1)=Acc;
 % Plot convergence
 bk1ls_fitness(k,:)=FS.c;
 
end
bk1ls_fitness(26,:)=mean(bk1ls_fitness,1);
bk1ls_acc(26,1)=mean(bk1ls_acc,1);
bk1ls_nf(26,1)=mean(bk1ls_nf,1);

bk1ls_fitness(27,1)=var(bk1ls_fitness(26,:),0,2); 
bk1ls_acc(27,1)=var(bk1ls_acc(1:26,1),0,1);             %����
bk1ls_nf(27,1)=var(bk1ls_nf(1:26,1),0,1);

bk1ls_fitness(28,1)=std(bk1ls_fitness(26,:),0,2); 
bk1ls_acc(28,1)=std(bk1ls_acc(1:26,1),0,1);             %��׼��
bk1ls_nf(28,1)=std(bk1ls_nf(1:26,1),0,1);

bk1ls_fitness(29,1)=min(bk1ls_fitness(26,:),[],2);
bk1ls_acc(29,1)=max(bk1ls_acc(1:26,1),[],1);          %
bk1ls_nf(29,1)=max(bk1ls_nf(1:26,1),[],1);

%% Number 3: (PF2LS) %��
pf2ls_acc=[];%��
pf2ls_fitness=[];%��
pf2ls_nf=[]; %��
for l=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_61.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('pf2ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 pf2ls_nf(l,1)=FS.nf;%��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 pf2ls_acc(l,1)=Acc;%��
 % Plot convergence
 pf2ls_fitness(l,:)=FS.c;%��
 
end
pf2ls_fitness(26,:)=mean(pf2ls_fitness,1);%��
pf2ls_acc(26,1)=mean(pf2ls_acc,1);%��
pf2ls_nf(26,1)=mean(pf2ls_nf,1);%��

pf2ls_fitness(27,1)=var(pf2ls_fitness(26,:),0,2); 
pf2ls_acc(27,1)=var(pf2ls_acc(1:26,1),0,1);             %����
pf2ls_nf(27,1)=var(pf2ls_nf(1:26,1),0,1);

pf2ls_fitness(28,1)=std(pf2ls_fitness(26,:),0,2); 
pf2ls_acc(28,1)=std(pf2ls_acc(1:26,1),0,1);             %��׼��
pf2ls_nf(28,1)=std(pf2ls_nf(1:26,1),0,1);

pf2ls_fitness(29,1)=min(pf2ls_fitness(26,:),[],2);
pf2ls_acc(29,1)=max(pf2ls_acc(1:26,1),[],1);          %
pf2ls_nf(29,1)=max(pf2ls_nf(1:26,1),[],1);

%% Number 4: (PF4LS) %��
pf4ls_acc=[];%��
pf4ls_fitness=[];%��
pf4ls_nf=[]; %��
for d=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_61.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('pf4ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 pf4ls_nf(d,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 pf4ls_acc(d,1)=Acc;%��2
 % Plot convergence
 pf4ls_fitness(d,:)=FS.c;%��2
 
end
pf4ls_fitness(26,:)=mean(pf4ls_fitness,1);%��
pf4ls_acc(26,1)=mean(pf4ls_acc,1);%��
pf4ls_nf(26,1)=mean(pf4ls_nf,1);%��

pf4ls_fitness(27,1)=var(pf4ls_fitness(26,:),0,2); 
pf4ls_acc(27,1)=var(pf4ls_acc(1:26,1),0,1);             %����
pf4ls_nf(27,1)=var(pf4ls_nf(1:26,1),0,1);

pf4ls_fitness(28,1)=std(pf4ls_fitness(26,:),0,2); 
pf4ls_acc(28,1)=std(pf4ls_acc(1:26,1),0,1);             %��׼��
pf4ls_nf(28,1)=std(pf4ls_nf(1:26,1),0,1);

pf4ls_fitness(29,1)=min(pf4ls_fitness(26,:),[],2);
pf4ls_acc(29,1)=max(pf4ls_acc(1:26,1),[],1);          %
pf4ls_nf(29,1)=max(pf4ls_nf(1:26,1),[],1);

%% Number 5: (PFA) %��
pfa_acc=[];%��
pfa_fitness=[];%��
pfa_nf=[]; %��
for x=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_61.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('pfa',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 pfa_nf(x,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 pfa_acc(x,1)=Acc;%��2
 % Plot convergence
 pfa_fitness(x,:)=FS.c;%��2
 
end
pfa_fitness(26,:)=mean(pfa_fitness,1);%��
pfa_acc(26,1)=mean(pfa_acc,1);%��
pfa_nf(26,1)=mean(pfa_nf,1);%��

pfa_fitness(27,1)=var(pfa_fitness(26,:),0,2); 
pfa_acc(27,1)=var(pfa_acc(1:26,1),0,1);             %����
pfa_nf(27,1)=var(pfa_nf(1:26,1),0,1);

pfa_fitness(28,1)=std(pfa_fitness(26,:),0,2); 
pfa_acc(28,1)=std(pfa_acc(1:26,1),0,1);             %��׼��
pfa_nf(28,1)=std(pfa_nf(1:26,1),0,1);

pfa_fitness(29,1)=min(pfa_fitness(26,:),[],2);
pfa_acc(29,1)=max(pfa_acc(1:26,1),[],1);          %
pfa_nf(29,1)=max(pfa_nf(1:26,1),[],1);
%% Number 6: (GNDO) %��
gndo_acc=[];%��
gndo_fitness=[];%��
gndo_nf=[]; %��
for y=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_61.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('gndo',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 gndo_nf(y,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 gndo_acc(y,1)=Acc;%��2
 % Plot convergence
 gndo_fitness(y,:)=FS.c;%��2
 
end
gndo_fitness(26,:)=mean(gndo_fitness,1);%��
gndo_acc(26,1)=mean(gndo_acc,1);%��
gndo_nf(26,1)=mean(gndo_nf,1);%��

gndo_fitness(27,1)=var(gndo_fitness(26,:),0,2); 
gndo_acc(27,1)=var(gndo_acc(1:26,1),0,1);             %����
gndo_nf(27,1)=var(gndo_nf(1:26,1),0,1);

gndo_fitness(28,1)=std(gndo_fitness(26,:),0,2); 
gndo_acc(28,1)=std(gndo_acc(1:26,1),0,1);             %��׼��
gndo_nf(28,1)=std(gndo_nf(1:26,1),0,1);

gndo_fitness(29,1)=min(gndo_fitness(26,:),[],2);
gndo_acc(29,1)=max(gndo_acc(1:26,1),[],1);          %
gndo_nf(29,1)=max(gndo_nf(1:26,1),[],1);

%% Number 7: (BOA) %��
boa_acc=[];%��
boa_fitness=[];%��
boa_nf=[]; %��
for h=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_61.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('boa',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 boa_nf(h,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 boa_acc(h,1)=Acc;%��2
 % Plot convergence
 boa_fitness(h,:)=FS.c;%��2
 
end
boa_fitness(26,:)=mean(boa_fitness,1);%��
boa_acc(26,1)=mean(boa_acc,1);%��
boa_nf(26,1)=mean(boa_nf,1);%��

boa_fitness(27,1)=var(boa_fitness(26,:),0,2); 
boa_acc(27,1)=var(boa_acc(1:26,1),0,1);             %����
boa_nf(27,1)=var(boa_nf(1:26,1),0,1);

boa_fitness(28,1)=std(boa_fitness(26,:),0,2); 
boa_acc(28,1)=std(boa_acc(1:26,1),0,1);             %��׼��
boa_nf(28,1)=std(boa_nf(1:26,1),0,1);

boa_fitness(29,1)=min(boa_fitness(26,:),[],2);
boa_acc(29,1)=max(boa_acc(1:26,1),[],1);          %
boa_nf(29,1)=max(boa_nf(1:26,1),[],1);

%% Number 8: ASO
aso_acc=[];
aso_fitness=[];
aso_nf=[];
for i=1:25
% Ratio of validation data
 ho = 0.075; 
% Common parameter settings 
opts.N  = 30;     % number of solutcions
opts.T  = 500;    % maximum number of iterations
% Load dataset
load rmb_61.mat;
% Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
% Perform feature selection 
FS     = jfs('aso',feat,label,opts);
% Define index of selected features
sf_idx = FS.sf;
aso_nf(i,1)=FS.nf;
% Accuracy  
Acc    = jknn(feat(:,sf_idx),label,opts); 
aso_acc(i,1)=Acc;
quanzhong=jknn(feat(:,sf_idx),label,opts)/(FS.nf/264);
% Plot convergence
aso_fitness(i,:)=FS.c;
end
aso_fitness(26,:)=mean(aso_fitness,1);
aso_acc(26,1)=mean(aso_acc,1);
aso_nf(26,1)=mean(aso_nf,1);

aso_fitness(27,1)=var(aso_fitness(26,:),0,2); 
aso_acc(27,1)=var(aso_acc(1:26,1),0,1);             %����
aso_nf(27,1)=var(aso_nf(1:26,1),0,1);

aso_fitness(28,1)=std(aso_fitness(26,:),0,2); 
aso_acc(28,1)=std(aso_acc(1:26,1),0,1);             %��׼��
aso_nf(28,1)=std(aso_nf(1:26,1),0,1);

aso_fitness(29,1)=min(aso_fitness(26,:),[],2);
aso_acc(29,1)=max(aso_acc(1:26,1),[],1);          %
aso_nf(29,1)=max(aso_nf(1:26,1),[],1);
%%��Ӧ�Ⱥ�������
figure(1);
plot(sma_fitness(26,:),'-gp','Color',[0.96 0.59 0.17],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.96 0.59 0.17],'MarkerSize',6,'LineWidth',1); hold on;
plot(bk1ls_fitness(26,:),'-b>','MarkerFaceColor','b','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(pf2ls_fitness(26,:),'-c<','MarkerFaceColor','c','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;                                    
plot(pf4ls_fitness(26,:),'-mh','MarkerFaceColor','m','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;  
plot(pfa_fitness(26,:),'-yo','Color',[0.08 0.6 0.25],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.08 0.6 0.25],'MarkerSize',6,'LineWidth',1); hold on;
plot(gndo_fitness(26,:),'-ks','MarkerFaceColor','k','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(boa_fitness(26,:),'-d','Color',[0.64 0.08 0.18],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.64 0.08 0.18],'MarkerSize',6,'LineWidth',1); hold on;
plot(aso_fitness(26,:),'-r*','MarkerFaceColor','r','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
box off;
%grid on;
xlabel('Number of Iterations','FontSize',10);
ylabel('Fitness Value','FontSize',10); 
legend('SMA','BK1LS','PF2LS','PF4LS','PFA','GNDO','BOA','ASO','FontSize',10);
title('Objective Space','FontSize',10);
%% ׼ȷ������
Aver_acc=[];
Aver_acc=[sma_acc(26,1),bk1ls_acc(26,1),pf2ls_acc(26,1),pf4ls_acc(26,1),pfa_acc(26,1),gndo_acc(26,1),boa_acc(26,1),aso_acc(26,1)]
figure(2);
hold on;
bar(Aver_acc,'FaceColor',[0.64 0.08 0.18],'EdgeColor',[0.64 0.08 0.18],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'SMA','BK1LS','PF2LS','PF4LS','PFA','GNDO','BOA','ASO','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Accuracy','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Recognition Accuracy','FontSize',10);
%%ʣ����������
Aver_nf=[];
Aver_nf=[sma_nf(26,1),bk1ls_nf(26,1),pf2ls_nf(26,1),pf4ls_nf(26,1),pfa_nf(26,1),gndo_nf(26,1),boa_nf(26,1),aso_nf(26,1)]
figure(3);
hold on;
bar(Aver_nf,'FaceColor',[0.96 0.59 0.17],'EdgeColor',[0.96 0.59 0.17],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'SMA','BK1LS','PF2LS','PF4LS','PFA','GNDO','BOA','ASO','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Remaining Features','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Remaining Features','FontSize',10);
toc 







