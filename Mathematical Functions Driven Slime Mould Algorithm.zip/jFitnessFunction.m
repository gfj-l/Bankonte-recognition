% Fitness Function KNN (9/12/2020)

function cost = jFitnessFunction(feat,label,X,opts)
% Default of [alpha; beta]
ws = [0.99; 0.01];

if isfield(opts,'ws'), ws = opts.ws; end

% Check if any feature exist
if sum(X == 1) == 0
  cost = 1;
else
  % Error rate
  error    = jwrapper_KNN(feat(:,X == 1),label,opts);
  % Number of selected features
  num_feat = sum(X == 1);
  % Total number of features
  max_feat = length(X); 
  % Set alpha & beta
  alpha    = ws(1); 
  beta     = ws(2);
  % Cost function 
  cost     = alpha * error + beta * (num_feat / max_feat); 
end
end


%---Call Functions-----------------------------------------------------
function error = jwrapper_KNN(sFeat,label,opts)
%if isfield(opts,'k'), k = opts.k; end
labelchart = unique(label);
if isfield(opts,'Model'), Model = opts.Model; end

% Define training & validation sets
trainIdx = Model.training;    testIdx = Model.test;
xtrain   = sFeat(trainIdx,:); ytrain  = label(trainIdx);
xvalid   = sFeat(testIdx,:);  yvalid  = label(testIdx); 

% Training model
%My_Model = fitcknn(xtrain,ytrain,'NumNeighbors',k); 

% ����Ԥ����,��ѵ�����Ͳ��Լ���һ����[0,1]����
[mtrain,ntrain] = size(xtrain);
[mtest,ntest] = size(xvalid);
dataset = [xtrain;xvalid];
% mapminmaxΪMATLAB�Դ��Ĺ�һ������
[dataset_scale,ps] = mapminmax(dataset',0,1);
dataset_scale = dataset_scale';
xtrain = dataset_scale(1:mtrain,:);
xvalid = dataset_scale( (mtrain+1):(mtrain+mtest),: );


cmd = [' -t ',num2str(2)];
My_Model=libsvmtrain(ytrain,xtrain,cmd); 

% Prediction
[predicted_label, accuracy, decision_values] =libsvmpredict(yvalid,xvalid,My_Model); 

CM = confusionmat(predicted_label,yvalid,'Order',labelchart);
stats = statsOfMeasure(CM);


total = length(yvalid);
right = sum(predicted_label == yvalid);

% Accuracy
Acc      = right / total;
% Error rate
error    = 1 - Acc; 
end












