% Wrapper Feature Selection Toolbox 
 
% There are more than 40 wrapper FS methods are offered 
% You may open < List_Method.m file > to check all available methods

%---Usage-------------------------------------------------------------
% If you wish to use 'PSO' (see example 1) then you write
% FS = jfs('pso',feat,label,opts);

% If you want to use 'SMA' (see example 2) then you write
% FS = jfs('sma',feat,label,opts);

% * All methods have different calling name (refer List_Method.m sf_idxfile)


%---Input-------------------------------------------------------------
% feat   : Feature vector matrix (Instances x Features)
% label  : Label matrix (Instances x 1)
% opts   : Parameter settings 
% opts.N : Number of solutions / population size (* for all methods)
% opts.T : Maximum number of iterations (* for all methods)
% opts.k : Number of k in k-nearest neighbor 

% Some methods have their specific parameters (example: PSO, GA, DE) 
% if you do not set them then they will define as default settings
% * you may open the < m.file > to view or change the parameters
% * you may use 'opts' to set the parameters of method (see example 1)
% * you may also change the < jFitnessFunction.m file >


%---Output------------------------------------------------------------
% FS    : Feature selection model (It contains several results)
% FS.sf : Index of selected features
% FS.ff : Selected features
% FS.nf : Number of selected features
% FS.c  : Convergence curve
% Acc   : Accuracy of validation model

tic
%% Number 1: BI1LS
clear, clc, close;
bi1ls_acc=[];%��
bi1ls_fitness=[];%��
bi1ls_nf=[];%��
for j=1:25         %��
% Ratio of validation data
 ho = 0.075; 
% % Common param eter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% 
 load rmb_B.mat; 
% Divide data into training and validation sets
 HO = cvpartition(label,'HoldOut',ho); 
 opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bi1ls',feat,label,opts);                 %��
 % Define index of selected features
 sf_idx = FS.sf;
 bi1ls_nf(j,1)=FS.nf;                                    %��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bi1ls_acc(j,1)=Acc;             %��
 % Plot convergence
 bi1ls_fitness(j,:)=FS.c;       %��
end
bi1ls_fitness(26,:)=mean(bi1ls_fitness,1);     %��
bi1ls_acc(26,1)=mean(bi1ls_acc,1);             %��
bi1ls_nf(26,1)=mean(bi1ls_nf,1)                %��

bi1ls_fitness(27,1)=var(bi1ls_fitness(26,:),0,2); 
bi1ls_acc(27,1)=var(bi1ls_acc(1:26,1),0,1);             %����
bi1ls_nf(27,1)=var(bi1ls_nf(1:26,1),0,1);

bi1ls_fitness(28,1)=std(bi1ls_fitness(26,:),0,2); 
bi1ls_acc(28,1)=std(bi1ls_acc(1:26,1),0,1);             %��׼��
bi1ls_nf(28,1)=std(bi1ls_nf(1:26,1),0,1);

bi1ls_fitness(29,1)=min(bi1ls_fitness(26,:),[],2);
bi1ls_acc(29,1)=max(bi1ls_acc(1:26,1),[],1);          %
bi1ls_nf(29,1)=max(bi1ls_nf(1:26,1),[],1);
    
%% Number 2: (bi4ls) 
bi4ls_acc=[];
bi4ls_fitness=[];
bi4ls_nf=[];
for k=1:25
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions
 opts.T  = 500;    % maximum number of iterations
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bi4ls',feat,label,opts);
 % Define index of selected features
 sf_idx = FS.sf;
 bi4ls_nf(k,1)=FS.nf;
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bi4ls_acc(k,1)=Acc;
 % Plot convergence
 bi4ls_fitness(k,:)=FS.c;
 
end
bi4ls_fitness(26,:)=mean(bi4ls_fitness,1);
bi4ls_acc(26,1)=mean(bi4ls_acc,1);
bi4ls_nf(26,1)=mean(bi4ls_nf,1);

bi4ls_fitness(27,1)=var(bi4ls_fitness(26,:),0,2); 
bi4ls_acc(27,1)=var(bi4ls_acc(1:26,1),0,1);             %����
bi4ls_nf(27,1)=var(bi4ls_nf(1:26,1),0,1);

bi4ls_fitness(28,1)=std(bi4ls_fitness(26,:),0,2); 
bi4ls_acc(28,1)=std(bi4ls_acc(1:26,1),0,1);             %��׼��
bi4ls_nf(28,1)=std(bi4ls_nf(1:26,1),0,1);

bi4ls_fitness(29,1)=min(bi4ls_fitness(26,:),[],2);
bi4ls_acc(29,1)=max(bi4ls_acc(1:26,1),[],1);          %
bi4ls_nf(29,1)=max(bi4ls_nf(1:26,1),[],1);

%% Number 3: (bj0ls) %��
bj0ls_acc=[];%��
bj0ls_fitness=[];%��
bj0ls_nf=[]; %��
for l=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bj0ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 bj0ls_nf(l,1)=FS.nf;%��
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bj0ls_acc(l,1)=Acc;%��
 % Plot convergence
 bj0ls_fitness(l,:)=FS.c;%��
 
end
bj0ls_fitness(26,:)=mean(bj0ls_fitness,1);%��
bj0ls_acc(26,1)=mean(bj0ls_acc,1);%��
bj0ls_nf(26,1)=mean(bj0ls_nf,1);%��

bj0ls_fitness(27,1)=var(bj0ls_fitness(26,:),0,2); 
bj0ls_acc(27,1)=var(bj0ls_acc(1:26,1),0,1);             %����
bj0ls_nf(27,1)=var(bj0ls_nf(1:26,1),0,1);

bj0ls_fitness(28,1)=std(bj0ls_fitness(26,:),0,2); 
bj0ls_acc(28,1)=std(bj0ls_acc(1:26,1),0,1);             %��׼��
bj0ls_nf(28,1)=std(bj0ls_nf(1:26,1),0,1);

bj0ls_fitness(29,1)=min(bj0ls_fitness(26,:),[],2);
bj0ls_acc(29,1)=max(bj0ls_acc(1:26,1),[],1);          %
bj0ls_nf(29,1)=max(bj0ls_nf(1:26,1),[],1);

%% Number 4: (bj2ls) %��
bj2ls_acc=[];%��
bj2ls_fitness=[];%��
bj2ls_nf=[]; %��
for d=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bj2ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 bj2ls_nf(d,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bj2ls_acc(d,1)=Acc;%��2
 % Plot convergence
 bj2ls_fitness(d,:)=FS.c;%��2
 
end
bj2ls_fitness(26,:)=mean(bj2ls_fitness,1);%��
bj2ls_acc(26,1)=mean(bj2ls_acc,1);%��
bj2ls_nf(26,1)=mean(bj2ls_nf,1);%��

bj2ls_fitness(27,1)=var(bj2ls_fitness(26,:),0,2); 
bj2ls_acc(27,1)=var(bj2ls_acc(1:26,1),0,1);             %����
bj2ls_nf(27,1)=var(bj2ls_nf(1:26,1),0,1);

bj2ls_fitness(28,1)=std(bj2ls_fitness(26,:),0,2); 
bj2ls_acc(28,1)=std(bj2ls_acc(1:26,1),0,1);             %��׼��
bj2ls_nf(28,1)=std(bj2ls_nf(1:26,1),0,1);

bj2ls_fitness(29,1)=min(bj2ls_fitness(26,:),[],2);
bj2ls_acc(29,1)=max(bj2ls_acc(1:26,1),[],1);          %
bj2ls_nf(29,1)=max(bj2ls_nf(1:26,1),[],1);

%% Number 5: (bk0ls) %��
bk0ls_acc=[];%��
bk0ls_fitness=[];%��
bk0ls_nf=[]; %��
for x=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bk0ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 bk0ls_nf(x,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bk0ls_acc(x,1)=Acc;%��2
 % Plot convergence
 bk0ls_fitness(x,:)=FS.c;%��2
 
end
bk0ls_fitness(26,:)=mean(bk0ls_fitness,1);%��
bk0ls_acc(26,1)=mean(bk0ls_acc,1);%��
bk0ls_nf(26,1)=mean(bk0ls_nf,1);%��

bk0ls_fitness(27,1)=var(bk0ls_fitness(26,:),0,2); 
bk0ls_acc(27,1)=var(bk0ls_acc(1:26,1),0,1);             %����
bk0ls_nf(27,1)=var(bk0ls_nf(1:26,1),0,1);

bk0ls_fitness(28,1)=std(bk0ls_fitness(26,:),0,2); 
bk0ls_acc(28,1)=std(bk0ls_acc(1:26,1),0,1);             %��׼��
bk0ls_nf(28,1)=std(bk0ls_nf(1:26,1),0,1);

bk0ls_fitness(29,1)=min(bk0ls_fitness(26,:),[],2);
bk0ls_acc(29,1)=max(bk0ls_acc(1:26,1),[],1);          %
bk0ls_nf(29,1)=max(bk0ls_nf(1:26,1),[],1);
%% Number 6: (bk1ls) %��
bk1ls_acc=[];%��
bk1ls_fitness=[];%��
bk1ls_nf=[]; %��
for y=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bk1ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 bk1ls_nf(y,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bk1ls_acc(y,1)=Acc;%��2
 % Plot convergence
 bk1ls_fitness(y,:)=FS.c;%��2
 
end
bk1ls_fitness(26,:)=mean(bk1ls_fitness,1);%��
bk1ls_acc(26,1)=mean(bk1ls_acc,1);%��
bk1ls_nf(26,1)=mean(bk1ls_nf,1);%��

bk1ls_fitness(27,1)=var(bk1ls_fitness(26,:),0,2); 
bk1ls_acc(27,1)=var(bk1ls_acc(1:26,1),0,1);             %����
bk1ls_nf(27,1)=var(bk1ls_nf(1:26,1),0,1);

bk1ls_fitness(28,1)=std(bk1ls_fitness(26,:),0,2); 
bk1ls_acc(28,1)=std(bk1ls_acc(1:26,1),0,1);             %��׼��
bk1ls_nf(28,1)=std(bk1ls_nf(1:26,1),0,1);

bk1ls_fitness(29,1)=min(bk1ls_fitness(26,:),[],2);
bk1ls_acc(29,1)=max(bk1ls_acc(1:26,1),[],1);          %
bk1ls_nf(29,1)=max(bk1ls_nf(1:26,1),[],1);

%% Number 7: (bk2ls) %��
bk2ls_acc=[];%��
bk2ls_fitness=[];%��
bk2ls_nf=[]; %��
for h=1:25     %��
% Ratio of validation data
 ho = 0.075; 
% % Common parameter settings 
 opts.N  = 30;     % number of solutions %��
 opts.T  = 500;    % maximum number of iterations %��
% % Load dataset
 load rmb_B.mat; 
 % Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
 % Perform feature selection 
 FS     = jfs('bk2ls',feat,label,opts);%��
 % Define index of selected features
 sf_idx = FS.sf;
 bk2ls_nf(h,1)=FS.nf;%��2
 % Accuracy  
 Acc    = jknn(feat(:,sf_idx),label,opts); 
 bk2ls_acc(h,1)=Acc;%��2
 % Plot convergence
 bk2ls_fitness(h,:)=FS.c;%��2
 
end
bk2ls_fitness(26,:)=mean(bk2ls_fitness,1);%��
bk2ls_acc(26,1)=mean(bk2ls_acc,1);%��
bk2ls_nf(26,1)=mean(bk2ls_nf,1);%��

bk2ls_fitness(27,1)=var(bk2ls_fitness(26,:),0,2); 
bk2ls_acc(27,1)=var(bk2ls_acc(1:26,1),0,1);             %����
bk2ls_nf(27,1)=var(bk2ls_nf(1:26,1),0,1);

bk2ls_fitness(28,1)=std(bk2ls_fitness(26,:),0,2); 
bk2ls_acc(28,1)=std(bk2ls_acc(1:26,1),0,1);             %��׼��
bk2ls_nf(28,1)=std(bk2ls_nf(1:26,1),0,1);

bk2ls_fitness(29,1)=min(bk2ls_fitness(26,:),[],2);
bk2ls_acc(29,1)=max(bk2ls_acc(1:26,1),[],1);          %
bk2ls_nf(29,1)=max(bk2ls_nf(1:26,1),[],1);

%% Number 8: by2ls
by2ls_acc=[];
by2ls_fitness=[];
by2ls_nf=[];
for i=1:25
% Ratio of validation data
 ho = 0.075; 
% Common parameter settings 
opts.N  = 30;     % number of solutcions
opts.T  = 500;    % maximum number of iterations
% Load dataset
load rmb_B.mat;
% Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO;
% Perform feature selection 
FS     = jfs('by2ls',feat,label,opts);
% Define index of selected features
sf_idx = FS.sf;
by2ls_nf(i,1)=FS.nf;
% Accuracy  
Acc    = jknn(feat(:,sf_idx),label,opts); 
by2ls_acc(i,1)=Acc;
quanzhong=jknn(feat(:,sf_idx),label,opts)/(FS.nf/264);
% Plot convergence
by2ls_fitness(i,:)=FS.c;
end
by2ls_fitness(26,:)=mean(by2ls_fitness,1);
by2ls_acc(26,1)=mean(by2ls_acc,1);
by2ls_nf(26,1)=mean(by2ls_nf,1);

by2ls_fitness(27,1)=var(by2ls_fitness(26,:),0,2); 
by2ls_acc(27,1)=var(by2ls_acc(1:26,1),0,1);             %����
by2ls_nf(27,1)=var(by2ls_nf(1:26,1),0,1);

by2ls_fitness(28,1)=std(by2ls_fitness(26,:),0,2); 
by2ls_acc(28,1)=std(by2ls_acc(1:26,1),0,1);             %��׼��
by2ls_nf(28,1)=std(by2ls_nf(1:26,1),0,1);

by2ls_fitness(29,1)=min(by2ls_fitness(26,:),[],2);
by2ls_acc(29,1)=max(by2ls_acc(1:26,1),[],1);          %
by2ls_nf(29,1)=max(by2ls_nf(1:26,1),[],1);
%%��Ӧ�Ⱥ�������
figure(1);
plot(bi1ls_fitness(26,:),'-gp','Color',[0.96 0.59 0.17],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.96 0.59 0.17],'MarkerSize',6,'LineWidth',1); hold on;
plot(bi4ls_fitness(26,:),'-b>','MarkerFaceColor','b','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(bj0ls_fitness(26,:),'-c<','MarkerFaceColor','c','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;                                    
plot(bj2ls_fitness(26,:),'-mh','MarkerFaceColor','m','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;  
plot(bk0ls_fitness(26,:),'-yo','Color',[0.08 0.6 0.25],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.08 0.6 0.25],'MarkerSize',6,'LineWidth',1); hold on;
plot(bk1ls_fitness(26,:),'-ks','MarkerFaceColor','k','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
plot(bk2ls_fitness(26,:),'-d','Color',[0.64 0.08 0.18],'MarkerIndices',1:25:500,'MarkerFaceColor',[0.64 0.08 0.18],'MarkerSize',6,'LineWidth',1); hold on;
plot(by2ls_fitness(26,:),'-r*','MarkerFaceColor','r','MarkerIndices',1:25:500,'MarkerSize',6,'LineWidth',1); hold on;
box off;
%grid on;
xlabel('Number of Iterations','FontSize',10);
ylabel('Fitness Value','FontSize',10); 
legend('BI1LS','BI4LS','BJ0LS','BJ2LS','BK0LS','BK1LS','BK2LS','BY2LS','FontSize',10);
title('Objective Space','FontSize',10);
%% ׼ȷ������
Aver_acc=[];
Aver_acc=[bi1ls_acc(26,1),bi4ls_acc(26,1),bj0ls_acc(26,1),bj2ls_acc(26,1),bk0ls_acc(26,1),bk1ls_acc(26,1),bk2ls_acc(26,1),by2ls_acc(26,1)]
figure(2);
hold on;
bar(Aver_acc,'FaceColor',[0.64 0.08 0.18],'EdgeColor',[0.64 0.08 0.18],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'BI1LS','BI4LS','BJ0LS','BJ2LS','BK0LS','BK1LS','BK2LS','BY2LS','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Accuracy','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Recognition Accuracy','FontSize',10);
%%ʣ����������
Aver_nf=[];
Aver_nf=[bi1ls_nf(26,1),bi4ls_nf(26,1),bj0ls_nf(26,1),bj2ls_nf(26,1),bk0ls_nf(26,1),bk1ls_nf(26,1),bk2ls_nf(26,1),by2ls_nf(26,1)]
figure(3);
hold on;
bar(Aver_nf,'FaceColor',[0.96 0.59 0.17],'EdgeColor',[0.96 0.59 0.17],'LineWidth',0.1,'BarWidth',0.5); 
set(gca, 'xTick', [1:1:8]);
set(gca,'XTickLabel',{'BI1LS','BI4LS','BJ0LS','BJ2LS','BK0LS','BK1LS','BK2LS','BY2LS','FontSize'});
box off;
%grid on;
xlabel('Algorithm','FontSize',10);
ylabel('Remaining Features','FontSize',10); 
%legend('HHO','PFA','GNDO','BOA','EPO','ASO','HGSO','SMA','FontSize',10);
title('Average Remaining Features','FontSize',10);
toc 







