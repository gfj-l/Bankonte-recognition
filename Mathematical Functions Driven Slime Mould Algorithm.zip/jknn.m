% K-nearest Neighbor (9/12/2020)

function [Acc,stats] = jknn(feat,label,opts)
% Default of k-value
%k = 5;
labelchart = unique(label);
%if isfield(opts,'k'), k = opts.k; end
if isfield(opts,'Model'), Model = opts.Model; end

% Define training & validation sets
trainIdx = Model.training;    testIdx = Model.test;
xtrain   = feat(trainIdx,:);  ytrain  = label(trainIdx);
xvalid   = feat(testIdx,:);   yvalid  = label(testIdx);   
% Training model
% My_Model = fitcknn(xtrain,ytrain,'NumNeighbors',k); 


[mtrain,ntrain] = size(xtrain);% ����Ԥ����,��ѵ�����Ͳ��Լ���һ����[0,1]����
[mtest,ntest] = size(xvalid);
dataset = [xtrain;xvalid];

[dataset_scale,ps] = mapminmax(dataset',0,1);% mapminmaxΪMATLAB�Դ��Ĺ�һ������
dataset_scale = dataset_scale';
xtrain = dataset_scale(1:mtrain,:);
xvalid = dataset_scale( (mtrain+1):(mtrain+mtest),: );

cmd = [' -t ',num2str(2)];
My_Model=libsvmtrain(ytrain,xtrain,cmd); % SVMѵ��ģ��


% Prediction
%pred     = predict(My_Model,xvalid);

[predicted_label, accuracy, decision_values] =libsvmpredict(yvalid,xvalid,My_Model); 

CM = confusionmat(predicted_label,yvalid,'Order',labelchart);
stats = statsOfMeasure(CM);

total = length(yvalid);
right = sum(predicted_label == yvalid);

% Accuracy
Acc      = right / total;
fprintf('\n Accuracy: %g %%',100 * Acc);
end


