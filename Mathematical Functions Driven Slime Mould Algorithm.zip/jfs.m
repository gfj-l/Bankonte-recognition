% Wrapper Feature Selection Toolbox by Jingwei Too - 9/12/2020

function model = jfs(type,feat,label,opts)
switch type
  % 2020
  case 'lsma'   ; fun = @LSMA;
  case 'pf2ls'  ; fun = @Levy_2_5t; 
  case 'pf3ls'  ; fun = @Levy_abs3; 
  case 'athls'  ; fun = @Levy_acoth75; 
  case 'achls'  ; fun = @Levy_acsch; 
  case 'bi1ls'  ; fun = @Levy_besseli1; 
  case 'bi4ls'  ; fun = @Levy_besseli4; 
  case 'bj0ls'   ; fun = @Levy_besselj0; 
  case 'bj2ls'  ; fun = @Levy_besselj2;
  case 'bk0ls'  ; fun = @Levy_besselk0; 
  case 'bk1ls'  ; fun = @Levy_besselk1_5;
  case 'bk2ls'  ; fun = @Levy_besselk2; 
  case 'by2ls'  ; fun = @Levy_bessely2; 
  case 'logls'  ; fun = @Levy_log10; 
  case 'cirls'  ; fun = @Levy_sqrt_1;
  case 'el1ls'  ; fun = @Levy_sqrt_4_1000; 
  case 'el2ls'  ; fun = @Levy_sqrt_8;  
  case 'el3ls'  ; fun = @Levy_sqrt_14; 
  case 'el4ls'  ; fun = @Levy_sqrt12; 
  case 'ef3ls'  ; fun = @Levy_zhishu_3;
  case 'pf4ls'  ; fun = @Levy5t; 
  case 'llsma'   ; fun = @Levy2_SMA; 
  case 'efls'   ; fun = @Lexp; 
  case 'aefls'   ; fun = @Laex; 
  case 'sma'  ; fun = @jSlimeMouldAlgorithm;
  case 'gndo' ; fun = @jGeneralizedNormalDistributionOptimization;
  case 'aso'  ; fun = @jAtomSearchOptimization; 
  case 'hho'  ; fun = @jHarrisHawksOptimization; 
  case 'hgso' ; fun = @jHenryGasSolubilityOptimization; 
  case 'pfa'  ; fun = @jPathFinderAlgorithm; 
  case 'boa'  ; fun = @jButterflyOptimizationAlgorithm;
  case 'epo'  ; fun = @jEmperorPenguinOptimizer; 
end
tic;
model = fun(feat,label,opts); 
% Computational time
t = toc;

model.t = t;
fprintf('\n Processing Time (s): %f % \n',t); fprintf('\n');
end


